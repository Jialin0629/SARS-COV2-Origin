#!/bin/sh
#PBS -S /bin/bash
 
#PBS -q batch
#PBS -N contree
#PBS -l nodes=1:ppn=1
#PBS -l mem=99gb
#PBS -l walltime=168:00:00
 
#PBS -M jy84696@uga.edu
#PBS -m ae
 
cd /scratch/jy84696/covid19/RAxML0929/JY/7contree
echo 'PBS_JOBID is $PBS_JOBID'
 
./raxmlHPC -mGTRCAT -J MRE -z outtrees_phylip -n outtrees_phylip.con.tre -p361275
 
