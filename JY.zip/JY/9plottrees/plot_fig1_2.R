######################################################################################################
######################################################################################################
####################################   Plot Consensus Tree   #########################################
######################################################################################################
######################################################################################################

library(phybase)
library(ape)
library(nodiv)
setwd('//Users/jialinyang/Documents/research/data/covid19genetree/my_output/RAxML0929/JY/9plottrees')
con_tree = read.tree("sptree.con.tre")
con_tree$node.label = as.integer(con_tree$node.label)
con_tree$tip.label = gsub("'","",con_tree$tip.label)
con_tree$tip.label = gsub(" ","_",con_tree$tip.label)
con_tree = root.phylo(con_tree,"8-addit-3228_S38_L001")
#
# Get all species names
#
spname = scan("label.txt", what = "character")
spname = sort(spname)
#View(table(origin_mat[,3]))

origin_mat = matrix(NA, nrow = 5248, ncol = 5)
colnames(origin_mat) = c("Names", "Origin","Country/Species","Continent","Color")

# 1. read original species names
origin_mat[,1] = spname # spname = rownames(mat1) 


# Origin Place
spname_loc = rep("", 5248)
for (i in grep("/", spname)){
  spname_loc[i] = tolower(unlist(strsplit(spname[i],split="/"))[2])
}
spname_loc[grep("Korea",spname)] = "south korea"
spname_loc[grep("Africa",spname)] = "south africa"
spname_loc[grep("Rhinolophus",spname)] = "bat"
spname_loc[grep("Hipposideros",spname)] = "bat"
spname_loc[grep("Rousettus_sp",spname)] = "bat"
spname_loc[grep("bat", spname)] = "bat"
spname_loc[grep("NC471", spname)] = "mers"
spname_loc[grep("addit", spname)] = "mers"
origin_mat[,2] = spname_loc

# 2.3. Country names
# Chinese city name
library(openxlsx)
cities_china = read.xlsx("cn.xlsx",sheet = 1, colNames = T)
names = c(tolower(cities_china$city),"tianmen",
          "anhui","fujian","gansu","guangdong","guizhou","hainan","hebei","heilongjiang","henan","hubei","wuhan-hu-1",
          "hunan","jiangsu","jiangxi","jilin","liaoning","qinghai","shaanxi","shanxi","shandong","sichuan","hong_",
          "yunnan","zhejiang","taiwan","guangxi","inner mongolia","ningxia","tibet","xinjiang","hong kong","macao")
names = names[-grep("india", names)]
# transfer city/province to country name
spname_country = spname_loc
for(i in 1:5248)
{
  if(length(grep(spname_loc[i], names, fixed=T))>0){spname_country[i]="china"}else
    if(length(grep(spname_loc[i], "nonthaburi", fixed=T))>0){spname_country[i]="thailand"}else
      if(length(grep(spname_loc[i], c("england","wales","scotland")))>0){spname_country[i]="uk"}else
        if(length(grep("czech", spname_loc[i]))>0){spname_country[i]="czech republic"}else
          if(length(grep("saudi", spname_loc[i]))>0){spname_country[i]="saudi arabia"}else
            if(length(grep("sri", spname_loc[i]))>0){spname_country[i]="sri lanka"}else
              if(length(grep("new", spname_loc[i]))>0){spname_country[i]="new zealand"}else
                if(length(grep("hong_", spname_loc[i]))>0){spname_country[i]="china"}
}
spname_country[spname_loc == "bat"] = "bat"
origin_mat[,3] = spname_country

# 4. Set Continent name
library(countrycode)
continent = countrycode(sourcevar = levels(as.factor(spname_country)), origin = "country.name", destination = "continent")
continent[is.na(continent)] = c("Bat","MERS","Pangolin")
for (i in 1:5248){
  origin_mat[i,4] = continent[grep(origin_mat[i,3],levels(as.factor(spname_country)))]
}

# 5. Set Continent Color
continentColor = c("#984ea3","#ffff33","#e41a1c","#f781bf","#4daf4a", "#a65628","#377eb8","#ff7f00")
continentPalette = levels(as.factor(continent))
for (i in 1:5248){
  origin_mat[i,5] = continentColor[grep(origin_mat[i,4],continentPalette)]
}

##############################################################################
##############################################################################
################################## PLOT 1 Species Tree #######################
##############################################################################
##############################################################################
library(RColorBrewer); library(ape); library(phangorn); library(diversitree)
library(ggtree);library(ggtreeExtra);library(ggstar)
library(ggplot2);library(ggraph)
library(ggnewscale);library(dplyr)
library(treeio)
library(tidytree)
library(TDbook)
##################################################
## info dataframe
# location
info = matrix(nrow=5248, ncol=3)
colnames(info) = c('id','location','location__colour')
for (i in 1:5248){
  info[i,] = origin_mat[grep(con_tree$tip.label[i], origin_mat[,1],fixed=T),c(1,4,5)]
}
info = as.data.frame(info)
# clade
info$clade = 'Z'
info$clade__colour = 'white'
clade_col = c('#66c2a4','#ffffb3','#bebada','#fb8072','#80b1d3','#fdb462','#b3de69','#fccde5','#d9d9d9')
clade = scan('clade_genome_names_0407.txt', what='character')
clade_names = c('Belgium,Germany,Iceland','WA-USA','NY,CT,WI-USA','NY,NJ-USA',
                'Netherlands,UK','Netherlands,Germany,Iceland','Wuhan, China',
                'France,Belgium,Switzerland','UK')
spname = gsub('_','',info[,1])
for(i in 1:9){
  clade_i = unlist(strsplit(clade[i],split=','))
  for(j in 1:length(clade_i)){
    info$clade[grep(clade_i[j],spname)]=paste('Clade',i)
  }
  start = grep(paste('Clade',i), info$clade)[1]
  end = grep(paste('Clade',i), info$clade)[length(grep(paste('Clade',i), info$clade))]
  info$clade[start:end] = clade_names[i]
  info$clade__colour[start:end]=clade_col[i]
}
info[1566,3:5]=info[1567,3:5]
# tip color
locationcolors = info %>% select(c("location", "location__colour")) %>% distinct()
locationcolors = locationcolors[order(locationcolors$location, decreasing=FALSE),]
# clade color
cladecolors = info %>% select(c("clade", "clade__colour")) %>% distinct()
cladecolors = cladecolors[order(cladecolors$clade, decreasing=FALSE),]
# node color
node_color = rep('NA', length(con_tree$node.label))
node_color[con_tree$node.label>=70] = 'red'
con_tree$node.label=con_tree$node.label[con_tree$node.label>=70]


p1 = ggtree(con_tree, layout='circular') %<+% info +
  #geom_tippoint(aes(color=location),size=0.1) + # add tip point
  #scale_color_manual(values=cols2) +            # tip point color
  scale_edge_width(0.01) + 
  geom_nodepoint(color=node_color,size=1, show.legend = FALSE,na.rm=TRUE)+
  guides(size = guide_legend(override.aes = list(shape = 1)))

p2 = p1 +
  new_scale_fill() +
  geom_fruit(
    geom=geom_tile,
    mapping=aes(fill=location),
    width=2,
    offset=0
  ) +
  scale_fill_manual(
    name="Continents",
    values=locationcolors$location__colour,
    guide=guide_legend(keywidth=15, keyheight=15)
  ) +
  theme(legend.position = c(0.5,0.48),
    legend.title=element_text(size=320), 
    legend.text=element_text(size=300)#,legend.spacing.y = unit(0.02, "cm")
  )
p3 = p2 +
  new_scale_fill() +
  geom_fruit(
    geom=geom_tile,
    mapping=aes(fill=clade),
    width=2,
    offset=0.1
  ) +
  scale_fill_manual(
    name="Clade",na.value = "blank",
    values=cladecolors$clade__colour,
    guide=guide_legend(keywidth=15, keyheight=15)
  ) +
  theme(legend.position = c(0.51,0.48),
    legend.title=element_text(size=320), 
    legend.text=element_text(size=300)#,legend.spacing.y = unit(0.02, "cm")
  )
pdf(file="Consensus_tree_RAxML0407_circular.pdf", width=200, height=200, onefile=TRUE) # 400 # width=25, height=500,
  par(xpd=NA)
  p3
dev.off()

##############################################################################
##############################################################################
################################## PLOT2 #####################################
##############################################################################
##############################################################################
setwd('/Users/jialinyang/Documents/research/data/covid19genetree/my output/RAxML0407/plots/plots_rm_names')
genes = c('M','orf7a','S')
boots = c('NC4714-3228_S73_L001','hCoV-19/pangolin/Guangxi/P3B/2017|EPI_ISL_410543|2017','NC4714-3228_S73_L001')
Plot_without_legend=function(gene,branch_width,tip_size,node_size){
  tree = read.tree(paste(genes[gene],"_0407_short.con.tre",sep=''))
  # root gene tree by Mers or midpoint
  tree = root.phylo(tree,boots[gene])
  if (gene==2){tree = phytools::midpoint.root(tree)}
  # Keep bootstrap support values no less than 70
  tree$node.label = as.integer(tree$node.label)
  node_color = rep('NA', length(tree$node.label))
  node_color[tree$node.label>=70] = 'red'
  tree$tip.label[grep('Rousettus',tree$tip.label)]='hCoV-19/Rousettus_sp/China/Rousettus_spp_Jinghong_2009|MG762674|11/1/09'
  # generate info dataframe
  idx=c()
  for (i in 1:length(tree$tip.label)){idx = c(idx, grep(tree$tip.label[i],info[,1],fixed=T))}
  info_i = info[idx,c(1,2,3)]
  info_i[2:length(tree$tip.label),] = info_i
  info_i[1,]=c("SARS-COV2-HUMAN-CLADE-5209",'Human','black')
  rownames(info_i) = 1:nrow(info_i)
  # plot
  cols2 = c(Bat='#f781bf',MERS="#a65628",Pangolin="#ff7f00",Human = 'black')
  p_i = ggtree(tree,size=branch_width) %<+% info_i +     # branch thickness
    geom_tippoint(aes(color=location),size=tip_size,shape=18) + 
    scale_color_manual(values=cols2, guide=guide_legend(title = 'Species'))+
    geom_nodepoint(color=node_color, alpha=1, size=node_size,shape=16)+
    theme_tree2()+xlim(0, 5)+ # geom_treescale(x=0.5,y=0, width = 0.5,linesize=1,fontsize = 8)
    theme(#legend.position = c(0.2,0.8),         #legend.position = "bottom"
          #legend.title=element_text(size=30),   #legend.title = element_text(size = 12),
          #legend.text=element_text(size=25),    #legend.text=element_text(size=25)
          #legend.spacing.y = unit(0.02, "cm"))  #legend.box = "vertical", legend.margin = margin()
          legend.position = 'none')
  return(p_i)
}
####### 1. Plot three gene trees  + legend separately######
# read gene tree
gene=1
p_i = Plot_without_legend(gene,1.5,8,3)
pdf(file=paste(genes[gene],"_0407.pdf",sep=''), width=10, height=6, onefile=TRUE) # 400 # width=25, height=500,
  par(xpd=NA)
  p_i
dev.off()
# read gene tree
gene=2
p_i = Plot_without_legend(gene,1.5,8,3)
pdf(file=paste(genes[gene],"_0407.pdf",sep=''), width=10, height=6, onefile=TRUE) # 400 # width=25, height=500,
  par(xpd=NA)
  p_i
dev.off()
# read gene tree
gene=3
p_i = Plot_without_legend(gene,1.5,8,3)
pdf(file=paste(genes[gene],"_0407.pdf",sep=''), width=10, height=6, onefile=TRUE) # 400 # width=25, height=500,
  par(xpd=NA)
  p_i
dev.off()

##############Plot legend #############
pdf(file=paste("legend.pdf",sep=''), width=10, height=6, onefile=TRUE) # 400 # width=25, height=500,
  par(xpd=NA)
  plot(NULL ,xaxt='n',yaxt='n',bty='n',ylab='',xlab='', xlim=0:1, ylim=0:1)
  legend("topleft", legend =c('Bat', 'MERS', 'Pangolin','Human'), 
         pch=18, pt.cex=4.5, cex=2.3, bty='n',
         col = c('#f781bf',"#a65628","#ff7f00",'black'))
  legend(x=-0.05,y=0.5, legend =c('Bootstrap Support>=70'), 
         pch=16, pt.cex=2.5, cex=2.8, bty='n',
         col = c('red'))
  mtext("Species", at=0.085, cex=2.8)
dev.off()#


##############2. Plot three gene trees  + legend together#############
p_1 = Plot_without_legend(1,branch_width=1,tip_size=4,node_size=1.5)
p_2 = Plot_without_legend(2,branch_width=1,tip_size=4,node_size=1.5)
p_3 = Plot_without_legend(3,branch_width=1,tip_size=4,node_size=1.5)
tree = read.tree(paste(genes[3],"_0407_short.con.tre",sep=''))
node_color = rep('NA', length(tree$node.label))
node_color[tree$node.label>=70] = 'red'
idx=c()
for (i in 1:length(tree$tip.label)){idx = c(idx, grep(tree$tip.label[i],info[,1],fixed=T))}
info_i = info[idx,c(1,2,3)]
cols2 = c(Bat='#f781bf',MERS="#a65628",Pangolin="#ff7f00",Human = 'black')
p_4 = ggtree(tree,size=1.5) %<+% info_i +                           # branch thickness
  geom_tippoint(aes(color=location),size=8,shape=18) +              # tip size
  scale_color_manual(values=cols2,
                     guide=guide_legend(title = 'Species'))+
  geom_nodepoint(color=node_color, alpha=1, size=3,shape=16)+          # node size
  theme_tree2()+xlim(0, 5)+  # geom_treescale(x=0.5,y=0, width = 0.5,linesize=1,fontsize = 8)
  theme(legend.position = c(0.26,0.5),
        legend.title = element_text(size = 15),#legend.title=element_text(size=30), 
        legend.text = element_text(size = 12))

library("cowplot")
legend = get_legend(p_4)
# get legend for bootstrap support values
df=as.data.frame(matrix(1:10,ncol=2))
colnames(df)=c('x','y')
p = ggplot(data = df, aes(x=x, y=y,color='red'))+geom_point(size=3)+
  theme(legend.key = element_rect(colour = "transparent", fill = "white"),
        legend.position = c(0.465,0.63),
        legend.text = element_text(size = 15))+
  scale_color_discrete(name =" ", labels=c(" Bootstrap Support >= 70"))
legend2 = get_legend(p)
# combine two legends
legends = plot_grid(legend,legend2,nrow = 2)

pdf(file=paste("Three_gene_trees_0407.pdf",sep=''), width=10, height=6, onefile=TRUE) # 400 # width=25, height=500,
  par(xpd=NA)
  plot_grid(p_1,p_2,p_3, legends,scale=rep(c(1,1,1,0.8)),
            label_size = 12,label_colour = "black",
            labels = c(genes,' '),nrow = 2)
dev.off()

######################################################################################################
######################################################################################################
#########################         short consensus tree                    ############################
######################################################################################################
######################################################################################################
######################################################################################################
setwd('/Users/jialinyang/Documents/research/data/covid19genetree/my output/RAxML0407/plots/plots_rm_names')
con_tree = read.tree("sptree.con.tre")
con_tree$node.label = as.integer(con_tree$node.label)
con_tree$tip.label = gsub("'","",con_tree$tip.label)
con_tree$tip.label = gsub(" ","_",con_tree$tip.label)
con_tree = root.phylo(con_tree,"8-addit-3228_S38_L001")

spname = con_tree$tip.label
# find non-human index in spname
pangolin_loc = grep("pangolin", spname)
bat_loc = grep("Rhinolophus",spname)
bat_loc = c(bat_loc, grep("Hipposideros",spname))
bat_loc = c(bat_loc, grep("Rousettus",spname))
bat_loc = c(bat_loc, grep("bat",spname))
mers_loc = grep("NC471",spname)
mers_loc = c(mers_loc,grep("addit",spname))
loc = sort(unique(c(bat_loc, mers_loc, pangolin_loc)))
# drop Human genomes
con_tree$tip.label[35] = "SARS-COV2-HUMAN-CLADE-5209"
short_tree = drop.tip(con_tree, c(36:5243))

# Plot
# Keep bootstrap support values no less than 70
node_color = rep('NA', length(short_tree$node.label))
node_color[short_tree$node.label>=70] = 'red'
short_tree$tip.label[grep('Rousettus',short_tree$tip.label)]='hCoV-19/Rousettus_sp/China/Rousettus_spp_Jinghong_2009|MG762674|11/1/09'
# generate info dataframe
idx=c()
for (i in 1:length(short_tree$tip.label)){idx = c(idx, grep(short_tree$tip.label[i],info[,1],fixed=T))}
info_i = info[idx,c(1,2,3)]
info_i[2:length(short_tree$tip.label),] = info_i
info_i[1,]=c("SARS-COV2-HUMAN-CLADE-5209",'Human','black')
rownames(info_i) = 1:nrow(info_i)
# plot
cols2 = c(Bat='#f781bf',MERS="#a65628",Pangolin="#ff7f00",Human = 'black')
p_i = ggtree(short_tree,size=13) %<+% info_i +     # branch thickness
  geom_tippoint(aes(color=location),size=180,shape=18) + 
  scale_color_manual(values=cols2, guide=guide_legend(title = 'Species'))+
  geom_nodepoint(color=node_color, alpha=1, size=80,shape=16)+
  theme(legend.position = c(0.2,0.8),         #legend.position = "bottom"
        legend.title=element_text(size=320),   #legend.title = element_text(size = 12),
        legend.text=element_text(size=300)   #legend.box = "vertical", legend.margin = margin()
        )
pdf(file=paste("Consensus_tree_short_0407.pdf",sep=''), width=200, height=200, onefile=TRUE) # 400 # width=25, height=500,
  par(xpd=NA)
  p_i
dev.off()


pdf(file=paste("Figure_2_short_0407.pdf",sep=''), width=400, height=200, onefile=TRUE) # 400 # width=25, height=500,
  par(xpd=NA)
  plot_grid(p3,p_i,scale=c(1,0.75),hjust=c(-1.5,-1.5),vjust=c(2.5,2.5),
            label_size = 511,label_colour = "black",
            labels = c('A','B'),nrow = 1)
dev.off()

